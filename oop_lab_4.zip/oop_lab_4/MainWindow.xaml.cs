﻿using System;
using System.Linq; // Для LINQ (Min, Max, Sum, OrderBy)
using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic; // Для List

namespace Lab4_Arrays
{
    /// <summary>
    /// Логіка взаємодії для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private double[] oneDArray; // Одновимірний масив
        private double[,] twoDArray; // Двовимірний масив
        private Random random = new Random(); // Для генерації випадкових чисел

        public MainWindow()
        {
            InitializeComponent();
            // Ініціалізуємо масиви при старті з тестовими даними або генерованими
            Process1DArray_Click(null, null); // Обробляємо 1D масив при старті
            Generate2DArray_Click(null, null); // Генеруємо 2D масив при старті
        }

        // === Методи для Одновимірного масиву ===

        /// <summary>
        /// Обробляє одновимірний масив: розраховує кількість від'ємних,
        /// суму модулів після мінімального за модулем,
        /// замінює від'ємні елементи їх квадратами та сортує масив.
        /// </summary>
        private void Process1DArray_Click(object sender, RoutedEventArgs e)
        {
            // Очищаємо попередні результати
            lblNegativeCount.Text = "";
            lblSumAfterMinAbs.Text = "";
            lbl1DArrayProcessed.Text = "";
            lbl1DArrayOriginal.Text = "";

            try
            {
                // Парсинг введених елементів масиву
                string input = txt1DArrayInput.Text.Trim();
                if (string.IsNullOrWhiteSpace(input))
                {
                    MessageBox.Show("Будь ласка, введіть елементи одновимірного масиву.", "Помилка вводу", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Розділяємо рядок на числа, дозволяючи пробіли, коми, крапки з комою
                oneDArray = input.Split(new char[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                                 .Select(s => double.Parse(s.Replace('.', ','))) // Замінюємо десяткову крапку на кому для парсингу
                                 .ToArray();

                lbl1DArrayOriginal.Text = string.Join(" ", oneDArray.Select(d => d.ToString("F2"))); // Виводимо початковий масив

                // a) Кількість від'ємних елементів масиву
                int negativeCount = oneDArray.Count(n => n < 0);
                lblNegativeCount.Text = negativeCount.ToString();

                // б) Сума модулів елементів масиву, розташованих після мінімального за модулем елементу
                if (oneDArray.Length == 0)
                {
                    lblSumAfterMinAbs.Text = "Масив порожній.";
                }
                else
                {
                    double minAbsValue = oneDArray.Min(n => Math.Abs(n));
                    int minAbsIndex = Array.IndexOf(oneDArray, oneDArray.First(n => Math.Abs(n) == minAbsValue));

                    double sumAfterMinAbs = 0;
                    for (int i = minAbsIndex + 1; i < oneDArray.Length; i++)
                    {
                        sumAfterMinAbs += Math.Abs(oneDArray[i]);
                    }
                    lblSumAfterMinAbs.Text = sumAfterMinAbs.ToString("F2");
                }

                // Замінити всі від'ємні елементи масиву їх квадратами
                double[] modifiedArray = (double[])oneDArray.Clone(); // Робимо копію, щоб не змінювати оригінал прямо
                for (int i = 0; i < modifiedArray.Length; i++)
                {
                    if (modifiedArray[i] < 0)
                    {
                        modifiedArray[i] = modifiedArray[i] * modifiedArray[i];
                    }
                }

                // Впорядкувати елементи масиву за зростанням
                Array.Sort(modifiedArray);

                lbl1DArrayProcessed.Text = string.Join(" ", modifiedArray.Select(d => d.ToString("F2")));
            }
            catch (FormatException)
            {
                MessageBox.Show("Помилка вводу: Будь ласка, введіть дійсні числа, розділені пробілами, комами або крапками з комою.", "Некоректний формат", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Виникла помилка: {ex.Message}", "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // === Методи для Двовимірного масиву ===

        /// <summary>
        /// Генерує випадковий двовимірний масив за вказаними розмірами.
        /// </summary>
        private void Generate2DArray_Click(object sender, RoutedEventArgs e)
        {
            lbl2DArraySecondColumn.Text = "";
            txt2DArrayAll.Text = "";
            lbl2DArrayMthRow.Text = ""; // Очищаємо результат m-го рядка

            int rows, cols;
            if (!int.TryParse(txtMatrixRows.Text, out rows) || rows <= 0)
            {
                MessageBox.Show("Будь ласка, введіть коректну кількість рядків (ціле додатнє число).", "Помилка вводу", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!int.TryParse(txtMatrixCols.Text, out cols) || cols <= 0)
            {
                MessageBox.Show("Будь ласка, введіть коректну кількість стовпців (ціле додатнє число).", "Помилка вводу", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            twoDArray = new double[rows, cols];
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    twoDArray[i, j] = Math.Round(random.NextDouble() * 20 - 10, 2); // Генеруємо числа від -10 до 10 з 2 знаками після коми
                    sb.Append($"{twoDArray[i, j]:F2}\t"); // Форматуємо для виводу
                }
                sb.AppendLine();
            }
            txt2DArrayAll.Text = sb.ToString();

            // Автоматично виводимо другий стовпець після генерації
            DisplaySecondColumn();
        }

        /// <summary>
        /// Виводить усі елементи другого стовпця двовимірного масиву.
        /// </summary>
        private void DisplaySecondColumn()
        {
            if (twoDArray == null || twoDArray.GetLength(1) < 2)
            {
                lbl2DArraySecondColumn.Text = "Масив не згенеровано або не має другого стовпця.";
                return;
            }

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            for (int i = 0; i < twoDArray.GetLength(0); i++) // GetLength(0) - кількість рядків
            {
                sb.Append($"{twoDArray[i, 1]:F2} "); // Елементи другого стовпця (індекс 1)
            }
            lbl2DArraySecondColumn.Text = sb.ToString().Trim();
        }

        /// <summary>
        /// Виводить усі елементи m-го рядка двовимірного масиву.
        /// </summary>
        private void DisplayMthRow_Click(object sender, RoutedEventArgs e)
        {
            lbl2DArrayMthRow.Text = ""; // Очищаємо попередній результат

            if (twoDArray == null)
            {
                lbl2DArrayMthRow.Text = "Двовимірний масив не згенеровано.";
                return;
            }

            int m; // Номер рядка (від користувача)
            if (!int.TryParse(txtMatrixRowM.Text, out m) || m <= 0 || m > twoDArray.GetLength(0))
            {
                MessageBox.Show($"Будь ласка, введіть коректний номер рядка (від 1 до {twoDArray.GetLength(0)}).", "Помилка вводу", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            // Важливо: користувач вводить номер рядка 'm' починаючи з 1, а індекси масиву починаються з 0.
            // Тому використовуємо (m - 1).
            for (int j = 0; j < twoDArray.GetLength(1); j++) // GetLength(1) - кількість стовпців
            {
                sb.Append($"{twoDArray[m - 1, j]:F2} ");
            }
            lbl2DArrayMthRow.Text = sb.ToString().Trim();
        }
    }
}